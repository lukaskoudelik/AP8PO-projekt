extends Area2D

@export var rod_path: NodePath
@export var hide_time := 6.5

@onready var rod = get_node_or_null(rod_path)
@onready var anim = $AnimatedSprite2D

var activated := false


func _ready():
	anim.play("default")


func _on_body_entered(body):
	if body.name == "Player" and !activated:
		activate()


func activate():

	if rod == null:
		print("Rod Path nie je nastavený!")
		return

	activated = true

	# animácia tlačítka dole
	anim.play("pressed")

	# skryje tyč
	set_rod_enabled(false)

	# čaká
	await get_tree().create_timer(hide_time).timeout

	# zobrazí tyč späť
	set_rod_enabled(true)

	# tlačítko hore
	anim.play("default")

	activated = false


func set_rod_enabled(enabled: bool):

	rod.visible = enabled

	var shape = rod.get_node("CollisionShape2D")

	shape.set_deferred("disabled", !enabled)
