extends AnimatableBody2D

@export var point_a := Vector2(0, 0)
@export var point_b := Vector2(-340, 0)
@export var speed := 110.0

var target

func _ready():
	target = point_b

func _physics_process(delta):

	position = position.move_toward(target, speed * delta)

	if position.distance_to(target) < 1:
		if target == point_b:
			target = point_a
		else:
			target = point_b
