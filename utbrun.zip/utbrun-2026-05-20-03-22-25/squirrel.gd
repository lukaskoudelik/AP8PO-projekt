extends Node2D

@export var pinecone_scene: PackedScene
@export var throw_interval := 2.0

@onready var throw_point = $ThrowPoint
@onready var anim = $AnimatedSprite2D


func _ready():
	anim.play("default")
	start_throwing()

func start_throwing():
	while true:
		await get_tree().create_timer(throw_interval).timeout
		throw_pinecone()

func throw_pinecone():
	if pinecone_scene == null:
		return

	var pinecone = pinecone_scene.instantiate()
	get_tree().current_scene.add_child(pinecone)
	pinecone.global_position = throw_point.global_position
