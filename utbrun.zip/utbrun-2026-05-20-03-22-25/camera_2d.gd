extends Camera2D

@onready var player = get_parent()

func _process(delta):
	global_position.x = player.global_position.x
	global_position.y = 324  # pevná výška kamery
