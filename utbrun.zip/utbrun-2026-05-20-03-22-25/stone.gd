extends StaticBody2D

@onready var collision = $CollisionShape2D
@onready var sprite = $Sprite2D
@onready var area = $Area2D

var is_gone := false


func _on_area_2d_body_entered(body):
	if body.name == "Player" and !is_gone:
		disappear()


func disappear():
	is_gone = true

	await get_tree().create_timer(1.5).timeout

	sprite.visible = false
	collision.disabled = true
	area.monitoring = false

	await get_tree().create_timer(3.0).timeout

	sprite.visible = true
	collision.disabled = false
	area.monitoring = true

	is_gone = false
