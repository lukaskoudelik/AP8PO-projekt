extends Area2D

@export var speed := 150.0

var direction := -1

@onready var sprite = $AnimatedSprite2D


func _ready():

	sprite.play("default")


func _physics_process(delta):

	global_position.x += speed * direction * delta

	if global_position.x < 7300:
		queue_free()


func _on_body_entered(body):

	if body.name == "Player":
		get_tree().current_scene.game_over()
