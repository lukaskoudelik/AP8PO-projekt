extends Node2D

@export var bird_scene: PackedScene

var game_started := false
var is_game_over := false

var start_position: Vector2
var respawn_position: Vector2
var fall_limit_y := 530
var score := 0


@onready var player = $Player
@onready var start_screen = $UI/StartScreen
@onready var game_over_screen = $UI/GameOverScreen
@onready var message_label = $UI/MessageLabel

@onready var l1 = $BG_Level1
@onready var l2 = $BG_Level2
@onready var l3 = $BG_Level3

var fade_speed := 2.5

@onready var end_screen = $UI/EndScreen

var game_ended := false
var time_elapsed := 0.0
var can_restart := false


func _ready():
	start_position = player.global_position
	respawn_position = start_position

	start_screen.visible = true
	game_over_screen.visible = false
	message_label.visible = false

	get_tree().paused = true
	randomize()


func add_score(amount):
	score += amount
	print("Score: ", score)


func show_message(text):
	message_label.text = text
	message_label.visible = true

	await get_tree().create_timer(2.0).timeout

	message_label.visible = false


func set_checkpoint(pos: Vector2):
	respawn_position = pos
	show_message("LEVEL COMPLETED!\n\ncheckpoint activated")


func _process(delta):
	var x = player.global_position.x

	if x < 11572:
		show_only(l1)

	elif x < 18600:
		show_only(l2)
		
	elif x < 20700:
		show_only(l1)

	else:
		show_only(l3)
		
	if game_started and !is_game_over:
		if player.global_position.y > fall_limit_y:
			game_over()
			
	if game_started and !is_game_over and !game_ended:
		time_elapsed += delta

	if player.global_position.x > 21944 and !game_ended:
		end_game()


func _unhandled_input(event):
	if !game_started and event.is_pressed():
		game_started = true
		start_screen.visible = false
		get_tree().paused = false

		start_bird_spawning()
		
	if game_ended and can_restart and event.is_pressed():
		get_tree().paused = false
		get_tree().reload_current_scene()


func game_over():
	if is_game_over:
		return

	is_game_over = true

	game_over_screen.visible = true
	player.set_physics_process(false)

	await get_tree().create_timer(0.7).timeout

	game_over_screen.visible = false
	reset_player()

	player.set_physics_process(true)
	is_game_over = false


func reset_player():
	player.global_position = respawn_position
	player.velocity = Vector2.ZERO


func start_bird_spawning():
	while game_started:
		await get_tree().create_timer(randf_range(2.0, 4.0)).timeout

		if !is_game_over:
			spawn_bird()


func spawn_bird():
	if bird_scene == null:
		return

	var bird = bird_scene.instantiate()
	add_child(bird)

	var random_y = randf_range(250, 450)
	bird.global_position = Vector2(10200, random_y)


func _on_area_2d_body_entered(body: Node2D) -> void:

	if body.name == "Player":
		game_over()

func show_only(active_level):
	l1.visible = (active_level == l1)
	l2.visible = (active_level == l2)
	l3.visible = (active_level == l3)
	
func end_game():

	game_ended = true
	get_tree().paused = true

	end_screen.visible = true

	$UI/EndScreen/Label_Coins.text = "Coins: " + str(score) + " / 5"

	var minutes = int(time_elapsed) / 60
	var seconds = int(time_elapsed) % 60
	$UI/EndScreen/Label_Time.text = "Time: %02d:%02d" % [minutes, seconds]

	$UI/EndScreen/Label_Restart.visible = false
	can_restart = false

	await get_tree().create_timer(5.0).timeout

	$UI/EndScreen/Label_Restart.visible = true

	can_restart = true
