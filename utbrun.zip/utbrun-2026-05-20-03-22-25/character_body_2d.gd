extends CharacterBody2D

const SPEED = 250.0
const JUMP_VELOCITY = -450.0
const GRAVITY = 1000.0

@onready var anim = $AnimatedSprite2D
@onready var col = $CollisionShape2D

var normal_size : Vector2
var crouch_size : Vector2

var is_crouching = false
var current_anim = ""


func _ready():
	var shape = col.shape as RectangleShape2D
	normal_size = shape.size
	crouch_size = Vector2(shape.size.x, shape.size.y * 0.5)


func _physics_process(delta):

	if not is_on_floor():
		velocity.y += GRAVITY * delta

	var direction = Input.get_axis("ui_left", "ui_right")
	var crouch_input = Input.is_action_pressed("ui_down") and is_on_floor()

	var speed = SPEED
	if crouch_input:
		speed *= 0.4

	if direction != 0:
		velocity.x = direction * speed
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY


	# CROUCH STATE CHANGE
	if crouch_input and not is_crouching:
		_enter_crouch()

	elif not crouch_input and is_crouching:
		_exit_crouch()


	# ANIMACE
	if not is_on_floor():
		play_anim("jump")

	elif is_crouching:
		play_anim("crouch")

	elif direction != 0:
		play_anim("run")

	else:
		play_anim("idle")


	if direction > 0:
		anim.flip_h = false
	elif direction < 0:
		anim.flip_h = true


	move_and_slide()


func play_anim(name):
	if current_anim == name:
		return
	current_anim = name
	anim.play(name)


# ✔ CROUCH ENTER
func _enter_crouch():
	is_crouching = true

	var shape = col.shape as RectangleShape2D

	var diff = normal_size.y - crouch_size.y

	shape.size = crouch_size

	# POSUN DOLŮ (KLÍČOVÉ!)
	col.position.y += diff * 0.5


# ✔ CROUCH EXIT
func _exit_crouch():
	is_crouching = false

	var shape = col.shape as RectangleShape2D

	var diff = normal_size.y - crouch_size.y

	shape.size = normal_size

	# POSUN ZPĚT
	col.position.y -= diff * 0.5
