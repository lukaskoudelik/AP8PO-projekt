extends Area2D

var activated := false


func _ready():
	body_entered.connect(_on_body_entered)


func _on_body_entered(body):
	if body.name == "Player" and !activated:
		activated = true
		get_tree().current_scene.set_checkpoint(global_position + Vector2(0, -50))
