extends Area2D

@export var cone_gravity := 900.0
@export var throw_force_x := 300.0
@export var throw_force_y := -350.0

var velocity := Vector2.ZERO


func _ready():
	velocity.x = throw_force_x
	velocity.y = throw_force_y


func _physics_process(delta):
	velocity.y += cone_gravity * delta
	global_position += velocity * delta

	if global_position.y > 800:
		queue_free()


func _on_body_entered(body):
	if body.name == "Player":
		get_tree().current_scene.game_over()
		queue_free()
