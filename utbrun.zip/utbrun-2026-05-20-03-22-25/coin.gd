extends Area2D

@export var value := 1

@onready var anim = $AnimatedSprite2D


func _ready():
	anim.play("default")


func _on_body_entered(body):
	if body.name == "Player":
		get_tree().current_scene.add_score(value)
		queue_free()
